#include "filename.hpp"

std::pair<std::string, std::string> split(std::string filename) {

  std::string basename;
  std::string extension;

  auto pos = filename.find_last_of('.');
  if (pos != std::string::npos) {
    basename = filename.substr(0, pos);
    extension = filename.substr(pos + 1, filename.size() - pos - 1);
  } else {
    basename = filename;
  }

  return std::make_pair(basename, extension);
}
