#ifndef FILENAME_HPP
#define FILENAME_HPP

#include <string>

/* split - split a string assuming it is a filename into its components:
the basename and the extension.

* The basename consists of characters from the start up to but not including
  the last '.' character.
* The extension consists of characters after the last '.' character to the
  end of the string.
* Returns a pair(basename, extension).
*/
std::pair<std::string, std::string> split(std::string filename);

#endif
