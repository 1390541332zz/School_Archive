#include "Interface.h"


int main(int argc, char *argv[])
{
  Interface inter;
  inter.doSomething();
  
  return 0;
}
