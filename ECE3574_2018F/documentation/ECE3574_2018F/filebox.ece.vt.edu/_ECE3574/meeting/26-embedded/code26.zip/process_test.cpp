#include <iostream>

static int x = 0;

struct Foo {
  static float data[10];
};

float Foo::data[10];

void print(const char * msg, void * loc)
{
    std::cout << msg << " : " << loc << std::endl;
}


int main()
{
  std::cout << "code" << std::endl;
  print("Address of main", (void *)&main);

  std::cout << "static" << std::endl;
  print("Address of static x", (void *)&x);
  print("Address of static Foo::data", (void *)&Foo::data);
  
  std::cout << "stack" << std::endl; 
  int x,y,z;
  print("Address of x", (void *)&x);
  print("Address of y", (void *)&y);
  print("Address of z", (void *)&z);

  std::cout << "heap" << std::endl; 
  double * a = new double;
  print("Address of a", (void *)a);
  
  short * b = new short;
  print("Address of b", (void *)b);

  delete a;
  
  int * c = new int;
  print("Address of c", (void *)c);

  double * d = new double;
  print("Address of d", (void *)d);

}
