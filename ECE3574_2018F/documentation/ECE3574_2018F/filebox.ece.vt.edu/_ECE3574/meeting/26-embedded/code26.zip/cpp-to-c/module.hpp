#ifndef MODULE_HPP
#define MODULE_HPP

class MyModule{
public:

  // Constructor
  MyModule();

  // Destructor
  ~MyModule();

  // Copy Constructor
  MyModule(const MyModule & rhs);

  // assignment
  MyModule & operator=(const MyModule & rhs);

  // API 
  int amethod();

private:

  // helpers
  void helper();

  // data
  int foo = 0;
  bool bar = false;
};


#endif
