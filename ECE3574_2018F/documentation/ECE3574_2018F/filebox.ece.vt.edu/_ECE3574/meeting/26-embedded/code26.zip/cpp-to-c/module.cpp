#include "module.hpp"

MyModule::MyModule(){}

MyModule::~MyModule(){}

MyModule::MyModule(const MyModule & rhs){}

MyModule & MyModule::operator=(const MyModule & rhs){
  return *this;
}

int MyModule::amethod(){

  helper();
  
  return foo;
}

void MyModule::helper(){
  // can access foo and bar
  foo = 1;
  bar = true;
}
