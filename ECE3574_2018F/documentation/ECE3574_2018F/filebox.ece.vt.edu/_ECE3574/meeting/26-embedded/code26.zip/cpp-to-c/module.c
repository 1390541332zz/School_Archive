#include "module.h"

// helpers
void helper(MyModulePtr this);

void init_MyModule(MyModulePtr this){
  this->foo = 0;
  this->bar = false;
}

void destroy_MyModule(MyModulePtr this){

}

void clone_MyModule(MyModulePtr this, MyModulePtr rhs){

}

int amethod(MyModulePtr this){

  helper(this);
  
  return this->foo;
}

void helper(MyModulePtr this){

  this->foo = 1;
  this->bar = true;
}
