#ifndef MODULE_H
#define MODULE_H

#include <stdbool.h>

struct MyModule{
  // data
  int foo;
  bool bar;
};

typedef struct MyModule * MyModulePtr;

// Constructor
void init_MyModule(MyModulePtr this);

// Destructor
void destroy_MyModule(MyModulePtr this);

// Copy Constructor
void clone_MyModule(MyModulePtr this, MyModulePtr rhs);

// assignment ?

// API 
int amethod(MyModulePtr this);

#endif
