#include <fstream>
#include <string>
#include <thread>
#include <sstream>

class Logger{
public:

  Logger(std::string filename){
    ofs.open(filename);
  };

  ~Logger(){
    ofs.close();
  };
  
  bool ok(){
    return ofs.good(); 
  }

  void write(std::string message){
    ofs << message << std::endl;
  }

private:

  std::ofstream ofs;
};

void thread_function(Logger & log){

  std::ostringstream oss;

  oss << "Thread " << std::this_thread::get_id() << " is alive.";
    
  log.write(oss.str());
  
}

int main()
{
  std::string logfile = "problem3.log";
  
  Logger logger(logfile);
    
  std::thread th1(thread_function, std::ref(logger));
  std::thread th2(thread_function, std::ref(logger));

  th1.join();
  th2.join();
  
  return EXIT_FAILURE;
}
