#ifndef DPARSE_HPP
#define DPARSE_HPP

#include <utility>
#include <string>

// parse a string to a double if possible
// returns (true,value) if possible
// returns (false, 0,.0) if not possible
std::pair<bool, double> dparse(const std::string & str);
      

#endif
