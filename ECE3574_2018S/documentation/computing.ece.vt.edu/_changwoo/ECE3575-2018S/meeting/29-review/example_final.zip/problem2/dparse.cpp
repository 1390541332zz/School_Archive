#include "dparse.hpp"

#include <sstream>


std::pair<bool, double> dparse(const std::string & str){
  double temp;
    
  std::istringstream iss(str);
  if(iss >> temp){
    // check for trailing characters if >> succeeds                                                                                      
    if(iss.rdbuf()->in_avail() != 0){
      return std::make_pair(false, 0.);;
    }

    return std::make_pair(true, temp);
  }

  return std::make_pair(false, 0.);
}
