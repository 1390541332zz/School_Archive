#include "stack.h"

// allocate 64k of space in 32 blocks
const int SPACE = 65536;
embed::StackAllocator<SPACE, 32> allocator;

// example type
struct MessageType
{
char num; // message number 0-255
char str[128]; // a fixed length string 
char str_len; // of length
};

// testing
#include <cassert>
int main()
{
    // large-ish object
    MessageType * mp = allocator.alloc<MessageType>();
    assert(mp != nullptr);
    assert(allocator.available() == (SPACE-sizeof(MessageType)));
	
    // a smaller size object
    int * anInt = allocator.alloc<int>();
    assert(mp != nullptr);
    assert(allocator.available() == (SPACE-sizeof(MessageType)-sizeof(int)));

    // use the objects
    mp->num = 0;
    *anInt = 4;
    
    // free the int
    allocator.free();

    // free the message;
    allocator.free();
	
    return 0;
}
