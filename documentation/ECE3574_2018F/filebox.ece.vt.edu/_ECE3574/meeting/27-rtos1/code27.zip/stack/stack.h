
#ifndef _STACK_H_
#define _STACK_H_

// stack holding N bytes in M frames
namespace embed
{
    typedef int SIZE_TYPE;
    typedef char UINT8;

    template<SIZE_TYPE N, SIZE_TYPE M>
    class StackAllocator
    {
    public:
	StackAllocator(): top(0), last(0) {};

	template<typename T>
	T * alloc(){
	    SIZE_TYPE space = sizeof(T);
	    if( (last + space >=N) || (top >=M) ) return nullptr;

	    T * loc = reinterpret_cast<T *>(&data[last]);
	    last += space;

	    block[top] = space;
	    ++top;

	    return loc;
	}

	bool free(){
	    if(top == 0) return false;

	    last = last - block[top];
	    --top;
	    return true;
	}

	SIZE_TYPE available(){
	    return N - last;
	}
	
    private:

	UINT8 data[N]; // block of N bytes
	SIZE_TYPE last; // location of last slot
	
	SIZE_TYPE block[M]; // stack of M blocks
	SIZE_TYPE top; // top of the block stack
    };
}

#endif // _STACK_H_
