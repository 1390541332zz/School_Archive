void yield()
{

}

void task()
{
    for( ;; ){
	yield();
    }
}
