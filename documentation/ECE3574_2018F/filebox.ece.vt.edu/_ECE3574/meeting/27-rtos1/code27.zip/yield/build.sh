#!/bin/sh
clang -c -S -nostdlib -fno-asynchronous-unwind-tables main.cpp
