
struct Sensor
{
    // fake call here
    // this would typically read from an A/D, 
    // or do a request on a (SPI/I2C/CAN) bus
    int read_sensor() { return 0; };
};

struct Actuator
{
    // fake call here
    // this would typically write to a DAC, 
    // or do a request on a (SPI/I2C/CAN) bus
    void update(int newtemp) {};
};

class TempController
{
public:
    TempController(int GainToUse): gain(GainToUse), target(0){};

    TempController(int GainToUse, int InitialTemp): gain(GainToUse), target(InitialTemp){};
    
    void read_update()
    {
	int current = input.read_sensor();
	// simple proportional control
	output.update(gain*(target - current));
    };
    
private:

    Sensor input;
    Actuator output;

    const int gain;
    int target;
};

// simple counter based debouncing
class KeyPad
{
public:
    static const char DEBOUNCE = 100;
    
    KeyPad(): s(IDLE), counter(0) {};
    
    void update(){
	switch(s){
	case IDLE:
	    key = read_raw_rowcol();
	    if(key){
		counter = 0;
		s = KEYDOWN;
	    }
	    break;
	case KEYDOWN:
	    if(key != read_raw_rowcol()){
		s = KEYUP;
	    } else {
		counter = (counter > DEBOUNCE) ? counter : counter+1;
	    }
	    break;
	case KEYUP:
	    if(counter > DEBOUNCE){
		// do something with key
	    }
	    counter = 0;
	    s = IDLE;
	    break;
	}
    }
    
private:
    // returns 0 if no key
    char read_raw_rowcol() {
	// read memory mapped IO for row/column
	// map to char
	return 0; // fake it
    }
    
    enum State {IDLE, KEYDOWN, KEYUP};
    State s;
    
    char key;
    char counter; // debounce counter
};

int main()
{
    const int GAIN = 1;
    TempController control(GAIN);

    KeyPad kp;
    
    for( ;; ){
	control.read_update();
	kp.update();
    }
}
