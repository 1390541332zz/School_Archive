
struct Sensor
{
    // fake call here
    // this would typically read from an A/D, 
    // or do a request on a (SPI/I2C/CAN) bus
    int read_sensor() { return 0; };
};

struct Actuator
{
    // fake call here
    // this would typically write to a DAC, 
    // or do a request on a (SPI/I2C/CAN) bus
    void update(int newtemp) {};
};

class TempController
{
public:
    TempController(int GainToUse): gain(GainToUse), target(0){};

    TempController(int GainToUse, int InitialTemp): gain(GainToUse), target(InitialTemp){};
    
    void read_update()
    {
	int current = input.read_sensor();
	// simple proportional control
	output.update(gain*(target - current));
    };
    
private:

    Sensor input;
    Actuator output;

    const int gain;
    int target;
};

// simple counter based debouncing
#include "ring_buffer.h"
class KeyPad
{
public:
    static const char DEBOUNCE = 100;
    static const std::size_t MAXEVENTS = 200;
    
    KeyPad(): counter(0) {};

    void poll(){
	key = read_raw_rowcol();
	if(key) event_queue.enqueue(KEYDOWN);
    }

    void key_down(){
	if(key != read_raw_rowcol()){
	    event_queue.enqueue(KEYUP);
	} else {
	    counter = (counter > DEBOUNCE) ? counter : counter+1;
	}
    }

    void key_up(){
	if(counter > DEBOUNCE){
	    // do something with key
	}
	counter = 0;
    }

    void process_events(){
	Event e;
	if(event_queue.dequeue(e)){
	    switch(e){
	    case KEYDOWN:
		key_down();
		break;
	    case KEYUP:
		key_up();
		break;
	    }
	       
	}
    }
    
private:

    char read_raw_rowcol() {
	// read memory mapped IO for row/column
	// map to char
	// this example only supports reading single key presses
	return 0; // fake it
    }

    enum Event {KEYDOWN, KEYUP};

    embed::RingBuffer<Event, MAXEVENTS> event_queue;
    
    char key;
    char counter; // debounce counter
};

int main()
{
    const int GAIN = 1;
    TempController control(GAIN);

    KeyPad kp;
    
    for( ;; ){
	control.read_update();
	kp.poll();
	kp.process_events();
    }
}
