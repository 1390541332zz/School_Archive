// This is a really simple message type, but it could be much more complex
// for example boost::variant, boost::any, or QVariant

#ifndef _MESSAGE_H_
#define _MESSAGE_H_

typedef int Message;

#endif // _MESSAGE_H_
