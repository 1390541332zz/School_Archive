#include <QtConcurrentRun> 
#include <QString>
#include <QDebug>

// exception handling omitted for clarity.
void thread_func(QString name)
{
  qInfo() << "Hello " << name << " from thread func with id = " << QThread::currentThreadId();
}

int main()
{
  qInfo() << "Starting thread func.";

  QFuture<void> future = QtConcurrent::run(thread_func, QString("class"));
  
  qInfo() << "Hello from main.";

  future.waitForFinished();
  
  return 0;
}
